A Pen created at CodePen.io. You can find this one at http://codepen.io/philhoyt/pen/ujHzd.

 I was in need of a very style agnostic drop down menu and struggling to find one. So I built one!

I have made subtle change for submenus to use top and bottom padding in conjunction with a smaller line-height to accommodate multi-lined sub-menu items.